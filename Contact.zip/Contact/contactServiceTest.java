package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class contactServiceTest {


	@Test
	public void methodAddPassTest() {
	    contactService contServe = new contactService();
	    contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
	    contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
	    contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertTrue(contServe.add(cont1));
	    assertTrue(contServe.add(cont2));
	    assertTrue(contServe.add(cont3));
	   }
	
	@Test
	public void methodAddFailTest() {
	    contactService contServe = new contactService();
	    contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
	    contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
	    contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertTrue(contServe.add(cont1));
	    assertFalse(contServe.add(cont1));
	    assertTrue(contServe.add(cont2));
	    assertTrue(contServe.add(cont3));
	   }
	
	@Test
	public void methodDeletePassTest() {
		contactService contServe = new contactService();
		contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
		contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertEquals(true, contServe.add(cont1));
	    assertEquals(true, contServe.add(cont2));
	    assertEquals(true, contServe.add(cont3));
	    assertEquals(true, contServe.remove("1000000003"));
	    assertEquals(true, contServe.remove("1000000002"));
	   }
	
	@Test
	public void methodDeleteFailTest() {
		contactService contServe = new contactService();
		contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
		contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertTrue(contServe.add(cont1));
	    assertTrue(contServe.add(cont2));
	    assertTrue(contServe.add(cont3));
	    assertFalse(contServe.remove("1000000055"));
	    assertTrue(contServe.remove("1000000001"));
	   }
	@Test
	public void updatePassTest() {
		contactService contServe = new contactService();
		contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
		contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertTrue(contServe.add(cont1));
	    assertTrue(contServe.add(cont2));
	    assertTrue(contServe.add(cont3));
	    assertTrue(contServe.update("1000000001", "Patrick", "", "", ""));
	    assertTrue(contServe.update("1000000003", "Jimbo", "", "", "14 Wallaby Wy"));
	}
	
	@Test
	public void updateFailTest() {
		contactService contServe = new contactService();
		contact cont1 = new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		contact cont2 = new contact("1000000002", "Dan", "Washington", "5558887777", "4 Wallaby Wy");
		contact cont3 = new contact("1000000003", "Austin", "Smith", "5559997777", "2 Wallaby Wy");
	    assertTrue(contServe.add(cont1));
	    assertTrue(contServe.add(cont2));
	    assertTrue(contServe.add(cont3));
	    assertFalse(contServe.update("1000000055", "Patrick", "", "", ""));
	    assertTrue(contServe.update("1000000003", "Jimbo", "", "", "14 Wallaby Wy"));
	}

}
