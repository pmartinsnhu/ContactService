package Contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class contactTest {

	@Test
	void testContact() {
		contact Contact1 = new contact("10000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		assertTrue(Contact1.getContactID().equals("10000001"));
		assertTrue(Contact1.getFirstName().equals("Pat"));
		assertTrue(Contact1.getLastName().equals("Martin"));
		assertTrue(Contact1.getPhoneNumber().equals("5556667777"));
		assertTrue(Contact1.getAddress().equals("42 Wallaby Wy"));
	}
	
	@Test
	void testContactIDTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("10000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testContactNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact(null, "Pat", "Martin", "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pattttttttt", "Martin", "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testFirstNameNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", null, "Martin", "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", "Martinnnnnn", "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testLastNameNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", null, "5556667777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testPhoneNumberLength() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", "Martin", "555666777", "42 Wallaby Wy");
		});
	}
	
	@Test
	void testPhoneNumberNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", "Martin", null, "42 Wallaby Wy");
		});
	}
	
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", "Martin", "5556667777", "42 Wallaby Wy..................");
		});
	}
	
	@Test
	void testAddressNotNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new contact("1000000001", "Pat", "Martin", "5556667777", null);
		});
	}

}
