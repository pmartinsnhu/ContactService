package Contact;

import java.security.InvalidParameterException;

public class contact {
	 // initialize variables
	   private String contactID;
	   private String firstName;
	   private String lastName;
	   private String phoneNumber;
	   private String address;

	   //  constructor
	   public contact(String contID, String fn, String ln, String pn, String add) {
	       if(contID == null) {
				throw new InvalidParameterException("contactID cannot be null.");
			}
			
			if(contID.length()>10) {
				throw new InvalidParameterException("contactID cannot be longer than 10 characters.");
			}
			this.contactID = contID;
			
		    if(fn == null) {
				throw new InvalidParameterException("First name cannot be null.");
			}	
			if(fn.length()>10) {
				throw new InvalidParameterException("First name cannot be longer than 10 characters.");
			}
		    this.firstName = fn;
		    
		    if(ln == null) {
				throw new InvalidParameterException("Last name cannot be null.");
			}		
			if(ln.length()>10) {
				throw new InvalidParameterException("Last name cannot be longer than 10 characters.");
			} 
		    this.lastName = ln;
		    
		    if(pn == null) {
				throw new InvalidParameterException("Phone number cannot be null.");
			}		
			if(pn.length()!= 10) {
				throw new InvalidParameterException("Phone number must be 10 characters.");
			} 
		    this.phoneNumber = pn;
		    
		    if(add == null) {
				throw new InvalidParameterException("Address cannot be null.");
			}		
			if(add.length() > 30) {
				throw new InvalidParameterException("Address cannot be longer than 30 characters.");
			}
		    this.address = add;
	   }

	   // setters/getters
	   public String getContactID() {
	       return contactID;
	   }

	   public String getFirstName() {
	       return firstName;
	   }

	   public void setFirstName(String firstName) {
	       this.firstName = firstName;
	   }

	   public String getLastName() {
	       return lastName;
	   }

	   public void setLastName(String lastName) {
	       this.lastName = lastName;
	   }
	   public String getPhoneNumber() {
	       return phoneNumber;
	   }

	   public void setPhoneNumber(String phoneNumber) {
	       this.phoneNumber = phoneNumber;
	   }

	   public String getAddress() {
	       return address;
	   }

	   public void setAddress(String add) {
	       this.address = add;
	   }

	   // compares two methods for likeness.
	   @Override
	   public boolean equals(Object object) {
	       if (this == object)
	           return true;
	       if (object == null)
	           return false;
	       if (getClass() != object.getClass())
	           return false;
	       contact other = (contact) object;
	       if (contactID == null) {
	           if (other.contactID != null)
	               return false;
	       } else if (!contactID.equals(other.contactID))
	           return false;
	       if (firstName == null) {
	           if (other.firstName != null)
	               return false;
	       } else if (!firstName.equals(other.firstName))
	           return false;
	       if (lastName == null) {
	           if (other.lastName != null)
	               return false;
	       } else if (!lastName.equals(other.lastName))
	           return false;
	       if (address == null) {
	           if (other.address != null)
	               return false;
	       } else if (!address.equals(other.address))
	           return false;
	       return true;
	   }
}
