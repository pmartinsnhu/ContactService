package Contact;

import java.util.ArrayList;

public class contactService {
   // list of contacts
   private ArrayList<contact> contacts;

   // constructor
   public contactService() {
       contacts = new ArrayList<>();
   }

   // checks if contact present in list, adds to list if not
   public boolean add(contact contact) {
       // checks if contact present
       boolean alreadyPresent = false;
       for (contact cont : contacts) {
           if (cont.equals(contact)) {
               alreadyPresent = true;
           }
       }
       // if not present, adds contact
       if (!alreadyPresent) {
           contacts.add(contact);
           System.out.println("Contact added");
           return true;
       } else {
           System.out.println("Contact already exists");
           return false;
       }
   }

   // removes contact if found in list
   public boolean remove(String contactID) {
       for (contact cont : contacts) {
           if (cont.getContactID().equals(contactID)) {
               contacts.remove(cont);
               System.out.println("Contact removed");
               return true;
           }
       }
       System.out.println("Contact not found");
       return false;
   }

   /*
    * updates the first name, last name, and address of provided contactID. 
    * pass empty string to leave attribute unchanged.
   */
   public boolean update(String contactID, String firstName, String lastName, String phoneNumber, String address) {
       for (contact cont : contacts) {
           if (cont.getContactID().equals(contactID)) {
               if (!firstName.equals(""))
                   cont.setFirstName(firstName);
               if (!lastName.equals(""))
                   cont.setLastName(lastName);
               if (!phoneNumber.equals(""))
                   cont.setPhoneNumber(phoneNumber);
               if (!address.equals(""))
                   cont.setAddress(address);
               System.out.println("Contact updated");
               return true;
           }
       }
       System.out.println("Contact not present");
       return false;
   }

}
